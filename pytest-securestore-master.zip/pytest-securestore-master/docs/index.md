# Welcome to pytest-securestore

An encrypted password store for use within pytest cases
